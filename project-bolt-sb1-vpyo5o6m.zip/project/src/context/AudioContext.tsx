import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';

interface AudioContextType {
  playStarSound: () => void;
  playBackgroundMusic: () => void;
  adjustBackgroundMusic: (starsCollected: number) => void;
}

const AudioContext = createContext<AudioContextType | undefined>(undefined);

export const useAudio = (): AudioContextType => {
  const context = useContext(AudioContext);
  if (!context) {
    throw new Error('useAudio must be used within an AudioProvider');
  }
  return context;
};

const createAudioElement = (src: string, loop: boolean = false, volume: number = 1.0) => {
  const audio = new Audio();
  audio.src = src;
  audio.loop = loop;
  audio.volume = volume;
  return audio;
};

export const AudioProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [starSounds] = useState([
    createAudioElement('/sounds/star-collect-1.mp3', false, 0.4), 
    createAudioElement('/sounds/star-collect-2.mp3', false, 0.3),
    createAudioElement('/sounds/star-collect-3.mp3', false, 0.3)
  ]);
  
  const [backgroundLayers] = useState([
    createAudioElement('/sounds/ambient-base.mp3', true, 0.0),
    createAudioElement('/sounds/ambient-layer-1.mp3', true, 0.0),
    createAudioElement('/sounds/ambient-layer-2.mp3', true, 0.0),
    createAudioElement('/sounds/ambient-layer-3.mp3', true, 0.0),
  ]);
  
  const [audioInitialized, setAudioInitialized] = useState(false);
  
  useEffect(() => {
    // Clean up audio on unmount
    return () => {
      starSounds.forEach(sound => {
        sound.pause();
        sound.currentTime = 0;
      });
      
      backgroundLayers.forEach(layer => {
        layer.pause();
        layer.currentTime = 0;
      });
    };
  }, [starSounds, backgroundLayers]);
  
  const playStarSound = useCallback(() => {
    const randomIndex = Math.floor(Math.random() * starSounds.length);
    const sound = starSounds[randomIndex];
    
    // Clone the audio to allow overlapping sounds
    const soundClone = sound.cloneNode() as HTMLAudioElement;
    soundClone.volume = sound.volume;
    soundClone.play().catch(error => console.error('Error playing star sound:', error));
  }, [starSounds]);
  
  const playBackgroundMusic = useCallback(() => {
    if (audioInitialized) return;
    
    // Start with just the base ambient layer
    backgroundLayers[0].volume = 0.3;
    backgroundLayers[0].play().catch(error => console.error('Error playing background music:', error));
    
    // Start other layers with 0 volume
    for (let i = 1; i < backgroundLayers.length; i++) {
      backgroundLayers[i].volume = 0;
      backgroundLayers[i].play().catch(error => console.error('Error playing background layer:', error));
    }
    
    setAudioInitialized(true);
  }, [backgroundLayers, audioInitialized]);
  
  const adjustBackgroundMusic = useCallback((starsCollected: number) => {
    // Determine how many layers should be active based on stars collected
    const totalStars = 12; // This should match the number of stars in the game
    
    backgroundLayers.forEach((layer, index) => {
      // Skip the base layer
      if (index === 0) return;
      
      // Calculate target volume based on progress
      const targetVolume = starsCollected >= (index * (totalStars / backgroundLayers.length))
        ? 0.2 + (index * 0.05) // Increase volume slightly for higher layers
        : 0;
      
      // Fade to target volume
      const fadeInterval = setInterval(() => {
        if (Math.abs(layer.volume - targetVolume) < 0.01) {
          layer.volume = targetVolume;
          clearInterval(fadeInterval);
          return;
        }
        
        layer.volume += layer.volume < targetVolume ? 0.01 : -0.01;
      }, 50);
    });
  }, [backgroundLayers]);
  
  return (
    <AudioContext.Provider value={{ playStarSound, playBackgroundMusic, adjustBackgroundMusic }}>
      {children}
    </AudioContext.Provider>
  );
};