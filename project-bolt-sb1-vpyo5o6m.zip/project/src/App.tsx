import React from 'react';
import Game from './components/Game';
import { AudioProvider } from './context/AudioContext';

function App() {
  return (
    <AudioProvider>
      <div className="min-h-screen bg-gradient-to-b from-indigo-950 via-purple-900 to-gray-900 flex items-center justify-center overflow-hidden">
        <Game />
      </div>
    </AudioProvider>
  );
}

export default App;