import React from 'react';
import { X } from 'lucide-react';

interface InfoModalProps {
  onClose: () => void;
}

const InfoModal: React.FC<InfoModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 flex items-center justify-center z-50 bg-black/70 backdrop-blur-sm">
      <div className="bg-indigo-950/90 border border-indigo-800 rounded-xl max-w-md w-full m-4 p-6 shadow-2xl animate-fade-in">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-light text-white">How to Play</h2>
          <button
            onClick={onClose}
            className="text-blue-300 hover:text-white transition-colors"
            aria-label="Close modal"
          >
            <X size={24} />
          </button>
        </div>
        
        <div className="space-y-4 text-blue-100">
          <p>Move your cursor (or finger on touch devices) to guide your celestial traveler through the night sky.</p>
          
          <p>Collect the glowing stars scattered throughout the cosmos. Each one you gather will add a new layer to the cosmic melody.</p>
          
          <p>Take your time and enjoy the tranquil experience - there is no rush or danger, only the peaceful exploration of a starlit sky.</p>
          
          <p className="text-sm text-blue-300 mt-6">
            For the best experience, use headphones to fully immerse yourself in the evolving soundscape.
          </p>
        </div>
      </div>
    </div>
  );
};

export default InfoModal;