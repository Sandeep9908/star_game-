import React from 'react';

interface PlayerCursorProps {
  x: number;
  y: number;
}

const PlayerCursor: React.FC<PlayerCursorProps> = ({ x, y }) => {
  return (
    <div 
      className="absolute pointer-events-none z-50"
      style={{
        left: `${x}px`,
        top: `${y}px`,
        transform: 'translate(-50%, -50%)',
      }}
    >
      <div className="relative">
        {/* Inner glow */}
        <div className="absolute w-6 h-6 bg-white rounded-full opacity-70 blur-sm" />
        
        {/* Center dot */}
        <div className="absolute w-3 h-3 bg-white rounded-full" 
          style={{ 
            left: '6px', 
            top: '6px',
            boxShadow: '0 0 8px 2px rgba(255, 255, 255, 0.8)'
          }} 
        />
        
        {/* Outer ring */}
        <div className="w-16 h-16 rounded-full border-2 border-white border-opacity-60 flex items-center justify-center"
          style={{ 
            boxShadow: '0 0 15px rgba(255, 255, 255, 0.3)',
            animation: 'pulse 2s infinite'
          }} 
        />
      </div>
    </div>
  );
};

export default PlayerCursor;