import React, { useEffect, useState } from 'react';

interface ScoreDisplayProps {
  score: number;
  total: number;
}

const ScoreDisplay: React.FC<ScoreDisplayProps> = ({ score, total }) => {
  const [animate, setAnimate] = useState(false);
  
  useEffect(() => {
    if (score > 0) {
      setAnimate(true);
      const timer = setTimeout(() => setAnimate(false), 700);
      return () => clearTimeout(timer);
    }
  }, [score]);

  return (
    <div className="absolute top-6 left-1/2 transform -translate-x-1/2">
      <div className={`text-white text-2xl md:text-3xl font-light tracking-wider transition-all
                      ${animate ? 'scale-125 text-yellow-200' : 'scale-100'}`}>
        <span>{score}</span>
        <span className="text-blue-300"> / </span>
        <span>{total}</span>
      </div>
      <div className="text-blue-200 text-sm text-center mt-1 opacity-70">
        Stars Collected
      </div>
    </div>
  );
};

export default ScoreDisplay;