import React from 'react';
import { StarType } from './Game';

interface StarProps {
  star: StarType;
}

const Star: React.FC<StarProps> = ({ star }) => {
  if (star.collected) {
    return null;
  }

  return (
    <div 
      className="absolute transition-all duration-500"
      style={{
        left: `${star.x}px`,
        top: `${star.y}px`,
        transform: 'translate(-50%, -50%)',
      }}
    >
      <div 
        className="animate-pulse"
        style={{
          width: `${star.size}px`,
          height: `${star.size}px`,
        }}
      >
        <div 
          className={`w-full h-full rounded-full bg-yellow-100 blur-sm opacity-30 absolute`}
          style={{
            animation: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
            animationDelay: `${Math.random() * 2}s`,
          }}
        />
        <div 
          className="w-full h-full flex items-center justify-center"
          style={{
            transform: 'rotate(45deg)',
          }}
        >
          <div 
            className="bg-yellow-100 absolute"
            style={{
              width: `${star.size * 0.8}px`,
              height: `${star.size * 0.8}px`,
              clipPath: 'polygon(50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%)',
              boxShadow: '0 0 15px 5px rgba(255, 255, 180, 0.6)',
            }}
          />
        </div>
      </div>
    </div>
  );
};

export default Star;