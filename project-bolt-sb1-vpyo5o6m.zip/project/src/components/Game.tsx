import React, { useState, useEffect, useRef } from 'react';
import Star from './Star';
import PlayerCursor from './PlayerCursor';
import { useAudio } from '../context/AudioContext';
import { Info } from 'lucide-react';
import ScoreDisplay from './ScoreDisplay';
import InfoModal from './InfoModal';
import BackgroundParticles from './BackgroundParticles';

export interface StarType {
  id: number;
  x: number;
  y: number;
  size: number;
  speed: number;
  direction: number;
  collected: boolean;
}

const Game: React.FC = () => {
  const [stars, setStars] = useState<StarType[]>([]);
  const [score, setScore] = useState(0);
  const [playerPos, setPlayerPos] = useState({ x: 0, y: 0 });
  const [isMoving, setIsMoving] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [gameStarted, setGameStarted] = useState(false);
  const gameAreaRef = useRef<HTMLDivElement>(null);
  const { playStarSound, playBackgroundMusic, adjustBackgroundMusic } = useAudio();

  useEffect(() => {
    if (!gameStarted) return;
    
    const generateStars = () => {
      const newStars: StarType[] = [];
      const gameArea = gameAreaRef.current;
      
      if (!gameArea) return [];
      
      const { width, height } = gameArea.getBoundingClientRect();
      
      for (let i = 0; i < 12; i++) {
        newStars.push({
          id: i,
          x: Math.random() * width,
          y: Math.random() * height,
          size: Math.random() * 20 + 20,
          speed: Math.random() * 0.5 + 0.2,
          direction: Math.random() * Math.PI * 2,
          collected: false
        });
      }
      
      return newStars;
    };
    
    setStars(generateStars());
    playBackgroundMusic();
    
    const handleResize = () => {
      setStars(generateStars());
    };
    
    window.addEventListener('resize', handleResize);
    
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [gameStarted, playBackgroundMusic]);

  useEffect(() => {
    if (!gameStarted) return;
    
    const moveStars = setInterval(() => {
      setStars(prevStars => {
        const gameArea = gameAreaRef.current;
        if (!gameArea) return prevStars;
        
        const { width, height } = gameArea.getBoundingClientRect();
        
        return prevStars.map(star => {
          if (star.collected) return star;
          
          let newX = star.x + Math.cos(star.direction) * star.speed;
          let newY = star.y + Math.sin(star.direction) * star.speed;
          let newDirection = star.direction;
          
          if (newX <= 0 || newX >= width) {
            newDirection = Math.PI - newDirection;
            newX = Math.max(0, Math.min(newX, width));
          }
          
          if (newY <= 0 || newY >= height) {
            newDirection = -newDirection;
            newY = Math.max(0, Math.min(newY, height));
          }
          
          if (Math.random() < 0.01) {
            newDirection = Math.random() * Math.PI * 2;
          }
          
          return {
            ...star,
            x: newX,
            y: newY,
            direction: newDirection
          };
        });
      });
    }, 16);
    
    return () => clearInterval(moveStars);
  }, [gameStarted]);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!gameAreaRef.current) return;
    
    const rect = gameAreaRef.current.getBoundingClientRect();
    setPlayerPos({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    });
    setIsMoving(true);
  };
  
  const handleTouchMove = (e: React.TouchEvent) => {
    if (!gameAreaRef.current) return;
    e.preventDefault();
    
    const touch = e.touches[0];
    const rect = gameAreaRef.current.getBoundingClientRect();
    setPlayerPos({
      x: touch.clientX - rect.left,
      y: touch.clientY - rect.top
    });
    setIsMoving(true);
  };
  
  const handleMouseLeave = () => {
    setIsMoving(false);
  };

  useEffect(() => {
    if (!gameStarted) return;
    
    const checkCollisions = () => {
      let collectedCount = 0;
      
      setStars(prevStars => 
        prevStars.map(star => {
          if (star.collected) {
            collectedCount++;
            return star;
          }
          
          const dx = star.x - playerPos.x;
          const dy = star.y - playerPos.y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          const collisionRadius = star.size / 2 + 15;
          
          if (distance < collisionRadius) {
            collectedCount++;
            playStarSound();
            return { ...star, collected: true };
          }
          return star;
        })
      );
      
      setScore(collectedCount);
      adjustBackgroundMusic(collectedCount);
    };
    
    const animationFrame = requestAnimationFrame(checkCollisions);
    
    return () => cancelAnimationFrame(animationFrame);
  }, [playerPos, stars, gameStarted, playStarSound, adjustBackgroundMusic]);

  const startGame = () => {
    setGameStarted(true);
  };

  if (!gameStarted) {
    return (
      <div className="w-full h-screen flex flex-col items-center justify-center px-4">
        <div className="text-center max-w-lg animate-fade-in">
          <h1 className="text-4xl md:text-5xl font-light text-white mb-6">Stellar Harmony</h1>
          <p className="text-lg text-blue-200 mb-8">
            Collect the floating stars in this peaceful night sky. 
            Each star you gather will transform the melody.
          </p>
          <button
            onClick={startGame}
            className="px-8 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-full 
                      text-lg transition-all duration-300 shadow-lg hover:shadow-indigo-500/50"
          >
            Begin Your Journey
          </button>
          <p className="mt-6 text-blue-300 text-sm">
            Best experienced with headphones
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full h-screen relative">
      <div 
        ref={gameAreaRef}
        className="w-full h-full cursor-none"
        onMouseMove={handleMouseMove}
        onTouchMove={handleTouchMove}
        onMouseLeave={handleMouseLeave}
      >
        <BackgroundParticles />
        
        {stars.map(star => (
          <Star 
            key={star.id} 
            star={star} 
          />
        ))}
        
        {isMoving && <PlayerCursor x={playerPos.x} y={playerPos.y} />}
        
        <ScoreDisplay score={score} total={stars.length} />
        
        <button 
          onClick={() => setShowModal(true)}
          className="absolute top-4 right-4 text-white p-2 rounded-full
                     bg-indigo-600/30 hover:bg-indigo-600/50 transition-colors duration-200"
          aria-label="Information"
        >
          <Info size={24} />
        </button>
        
        {showModal && <InfoModal onClose={() => setShowModal(false)} />}
      </div>
    </div>
  );
};

export default Game;